# kmu-cs-web-client-161
To manage course project material in Kookmin University WebClient Computing
